from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select

# self
from config.db import Data,DataNoCommit
from do.generate_table import GenerateTable,GenerateTableCreate, GenerateTableLogin, GenerateTablePublic


class GenerateTableDao:

    @DataNoCommit
    async def add(generate_table: GenerateTable, session=AsyncSession) -> str:
        """插入一个新的generate_table"""
        db_generate_table = GenerateTable.model_validate(generate_table)
        session.add(db_generate_table)
        await session.commit() 
        return db_generate_table.id

    @Data
    async def delete(id: str, session=AsyncSession):
        hero = await session.get(GenerateTable, id)
        return await session.delete(hero)

    @Data
    async def update(generate_table: GenerateTable, session=AsyncSession):
        """更新generate_table信息"""
        generate_table_to_upadte:GenerateTable = await session.get(GenerateTable, generate_table.id)
        generate_table_to_upadte.name = generate_table.name
        generate_table_to_upadte.email = generate_table.email
        session.add(generate_table_to_upadte)
        await session.commit()  # 提交事务
        session.refresh(generate_table_to_upadte)
        return generate_table_to_upadte

    @DataNoCommit
    async def select(id: str, session=AsyncSession) -> GenerateTable | None:
        return await session.get(GenerateTable, id)
    
    @DataNoCommit
    async def list(session=AsyncSession) -> list[GenerateTable]:
        result = await session.exec(select(GenerateTable))
        generate_tables = result.all()
        return generate_tables
