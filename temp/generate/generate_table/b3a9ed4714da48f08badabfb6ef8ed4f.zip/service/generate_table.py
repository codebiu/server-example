# self
from do.generate_table import GenerateTable
from dao.generate_table import UserDao

# lib


class UserService:
    """generate_table"""

    @staticmethod
    async def add(generate_table: GenerateTable)->str:
        return await UserDao.add(generate_table)

    @staticmethod
    async def delete(id: str):
        await UserDao.delete(id)

    @staticmethod
    async def update(generate_table: GenerateTable):
        await UserDao.update(generate_table)

    @staticmethod
    async def select(id: str) -> GenerateTable | None:
        return await UserDao.select(id)
    @staticmethod
    async def select_by_email(email: str) -> GenerateTable | None:
        return await UserDao.select_by_email(email)
    @staticmethod
    async def select_by_tel(tel: str) -> GenerateTable | None:
        return await UserDao.select_by_tel(tel)
    
    @staticmethod
    async def list() -> list[GenerateTable]:
        return await UserDao.list()
