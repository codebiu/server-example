# self
# from config.log import logger
from config.server import app
from service.generate_table import GenerateTableService
from do.generate_table import GenerateTable, GenerateTableCreate

# lib
from fastapi.responses import JSONResponse
from fastapi import APIRouter, status

router = APIRouter()

@router.post("/", status_code=status.HTTP_201_CREATED, summary="添加generate_table返回id")
async def add(generate_table: GenerateTable) -> str:
    return await GenerateTableService.add(generate_table)


@router.delete("/")
async def delete(id: str):
    await GenerateTableService.delete(id)

@router.put("/")
async def update(generate_table: GenerateTable):
    await GenerateTableService.update(generate_table)


@router.get("/", status_code=status.HTTP_201_CREATED)
async def select(id: str) -> GenerateTable | None:
    return await GenerateTableService.select(id)


@router.get("/list", status_code=status.HTTP_201_CREATED)
async def list() -> list[GenerateTable]:
    return await GenerateTableService.list()

app.include_router(router, prefix="/generate_table", tags=["generate_table_tags"])
