# self
# from config.log import logger
from config.server import app
from service.generate_table1 import GenerateTable1Service
from do.generate_table1 import GenerateTable1, GenerateTable1Create

# lib
from fastapi.responses import JSONResponse
from fastapi import APIRouter, status

router = APIRouter()

@router.post("/", status_code=status.HTTP_201_CREATED, summary="添加generate_table1返回id")
async def add(generate_table1: GenerateTable1) -> str:
    return await GenerateTable1Service.add(generate_table1)


@router.delete("/")
async def delete(id: str):
    await GenerateTable1Service.delete(id)

@router.put("/")
async def update(generate_table1: GenerateTable1):
    await GenerateTable1Service.update(generate_table1)


@router.get("/", status_code=status.HTTP_201_CREATED)
async def select(id: str) -> GenerateTable1 | None:
    return await GenerateTable1Service.select(id)


@router.get("/list", status_code=status.HTTP_201_CREATED)
async def list() -> list[GenerateTable1]:
    return await GenerateTable1Service.list()

app.include_router(router, prefix="/generate_table1", tags=["generate_table1_tags"])
