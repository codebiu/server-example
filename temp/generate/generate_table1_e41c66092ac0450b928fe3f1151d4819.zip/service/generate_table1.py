# self
from do.generate_table1 import GenerateTable1
from dao.generate_table1 import UserDao

# lib


class UserService:
    """generate_table1"""

    @staticmethod
    async def add(generate_table1: GenerateTable1)->str:
        return await UserDao.add(generate_table1)

    @staticmethod
    async def delete(id: str):
        await UserDao.delete(id)

    @staticmethod
    async def update(generate_table1: GenerateTable1):
        await UserDao.update(generate_table1)

    @staticmethod
    async def select(id: str) -> GenerateTable1 | None:
        return await UserDao.select(id)
    @staticmethod
    async def select_by_email(email: str) -> GenerateTable1 | None:
        return await UserDao.select_by_email(email)
    @staticmethod
    async def select_by_tel(tel: str) -> GenerateTable1 | None:
        return await UserDao.select_by_tel(tel)
    
    @staticmethod
    async def list() -> list[GenerateTable1]:
        return await UserDao.list()
