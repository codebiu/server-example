from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select

# self
from config.db import Data,DataNoCommit
from do.generate_table1 import GenerateTable1,GenerateTable1Create, GenerateTable1Login, GenerateTable1Public


class GenerateTable1Dao:

    @DataNoCommit
    async def add(generate_table1: GenerateTable1, session=AsyncSession) -> str:
        """插入一个新的generate_table1"""
        db_generate_table1 = GenerateTable1.model_validate(generate_table1)
        session.add(db_generate_table1)
        await session.commit() 
        return db_generate_table1.id

    @Data
    async def delete(id: str, session=AsyncSession):
        hero = await session.get(GenerateTable1, id)
        return await session.delete(hero)

    @Data
    async def update(generate_table1: GenerateTable1, session=AsyncSession):
        """更新generate_table1信息"""
        generate_table1_to_upadte:GenerateTable1 = await session.get(GenerateTable1, generate_table1.id)
        generate_table1_to_upadte.name = generate_table1.name
        generate_table1_to_upadte.email = generate_table1.email
        session.add(generate_table1_to_upadte)
        await session.commit()  # 提交事务
        session.refresh(generate_table1_to_upadte)
        return generate_table1_to_upadte

    @DataNoCommit
    async def select(id: str, session=AsyncSession) -> GenerateTable1 | None:
        return await session.get(GenerateTable1, id)
    
    @DataNoCommit
    async def list(session=AsyncSession) -> list[GenerateTable1]:
        result = await session.exec(select(GenerateTable1))
        generate_table1s = result.all()
        return generate_table1s
